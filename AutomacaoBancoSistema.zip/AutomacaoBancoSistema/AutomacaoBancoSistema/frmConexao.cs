﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;

namespace AutomacaoBancoSistema
{
    public partial class frmConexao : Form
    {
        public frmConexao()
        {
            InitializeComponent();
            CarregarDadosSistema();
            ExbirVersoesSistema();
        }
        private void ExibirInfoSQL()
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

                builder.DataSource = $@"{Environment.MachineName}\{cmbInstanciaSQL.Text}";
                builder.UserID = "sa";
                builder.Password = "DESKSql6428";
                builder.InitialCatalog = "master";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    string sql = "SELECT @@VERSION";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                txtSQLInfo.Text = reader.GetString(0);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ExibirInstanciaSQL()
        {
            try
            {

                SqlDataSourceEnumerator instance =
                  SqlDataSourceEnumerator.Instance;
                DataTable table = instance.GetDataSources();
                DataRow[] rows = table.Select();
                cmbInstanciaSQL.Items.Clear();
                foreach (DataRow row in rows)
                {
                    cmbInstanciaSQL.Items.Add(row[1]);
                }
                if (cmbInstanciaSQL.Items.Count > 0)
                {
                    cmbInstanciaSQL.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ExibirBancoDeDados()
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

                builder.DataSource = $@"{Environment.MachineName}\{cmbInstanciaSQL.Text}";
                builder.UserID = "sa";
                builder.Password = "DESKSql6428";
                builder.InitialCatalog = "master";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    string sql = "SELECT name FROM sys.databases";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        cmbBancoDeDados.Items.Clear();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cmbBancoDeDados.Items.Add(reader.GetString(0));
                            }
                        }
                        if (cmbBancoDeDados.Items.Count > 0)
                        {
                            cmbBancoDeDados.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ExbirVersoesSistema()
        {
            string diretorioSistema = ConfigurationManager.AppSettings.Get("repositorioSistema");
            cmbVersaoSistemaAtual.Items.Clear();
            foreach (string item in Directory.GetDirectories(diretorioSistema))
            {
                string diretorio = item.Remove(0, diretorioSistema.Length + 1);

                if (diretorio.Length > 5)
                {
                    if (diretorio.Substring(0, 6).ToLower() == "versao")
                    {
                        cmbVersaoSistemaAtual.Items.Add(diretorio.Substring(6, diretorio.Length - 6));
                    }
                }
                
            }
            if (cmbVersaoSistemaAtual.Items.Count > 0)
            {
                cmbVersaoSistemaAtual.SelectedIndex = cmbVersaoSistemaAtual.Items.Count - 1;
            }
        }

        private void CopiarSistemaVersao(string dirOrigem, string dirDestino, bool recursive)
        {
            // Cria o diretório de destino
            var dir = new DirectoryInfo(dirOrigem);

            //Verifica se o diretório fonte existe
            if (!dir.Exists)
                throw new DirectoryNotFoundException($"Diretório de origem não encontrado: {dir.FullName}");

            // Armazena os diretórios em cache antes de começarmos a copiar
            DirectoryInfo[] dirs = dir.GetDirectories();

            // Cria o diretório de destino
            Directory.CreateDirectory(dirDestino);

            //Pegue os arquivos no diretório de origem e copie para o diretório de destino
            foreach (FileInfo file in dir.GetFiles())
            {
                string caminhoArquivoDestino = Path.Combine(dirDestino, file.Name);
                file.CopyTo(caminhoArquivoDestino, true);
            }

            // Se for recursivo e copiar subdiretórios, chame este método recursivamente
            if (recursive)
            {
                foreach (DirectoryInfo subDir in dirs)
                {
                    string novoDiretorioDestino = Path.Combine(dirDestino, subDir.Name);
                    CopiarSistemaVersao(subDir.FullName, novoDiretorioDestino, true);
                }
            }

        }
        private void CarregarDadosSistema()
        {
            try
            {
                grpInfoSistema.Text = $"Informações do Sistema {ConfigurationManager.AppSettings.Get("infoSistema")}";
                txtRepositorioSistema.Text = ConfigurationManager.AppSettings.Get("repositorioSistema");
                txtDiretorioSistema.Text = ConfigurationManager.AppSettings.Get("diretorioSistema");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            try
            {
                CopiarSistemaVersao($@"{txtRepositorioSistema.Text}\Versao{cmbVersaoSistemaAtual.Text}".ToLower(), $@"{txtDiretorioSistema.Text}", true);
                string zipPasta = $@"{txtDiretorioSistema.Text}";
                string extrairPasta = $@"{txtDiretorioSistema.Text}";

                //ZipFile.CreateFromDirectory(origemPasta, zipPath);

                // Cria o diretório de destino
                var dir = new DirectoryInfo(extrairPasta);

                //Verifica se o diretório fonte existe
                if (!dir.Exists)
                    throw new DirectoryNotFoundException($"Diretório de origem não encontrado: {dir.FullName}");

                // Armazena os diretórios em cache antes de começarmos a copiar
                DirectoryInfo[] dirs = dir.GetDirectories();

                // Cria o diretório de destino
                Directory.CreateDirectory(extrairPasta);

                //Pegue os arquivos no diretório de origem e copie para o diretório de destino
                foreach (FileInfo file in dir.GetFiles())
                {
                    if (file.Extension == ".rar" || file.Extension == ".zip")
                    {
                        string pasta = file.FullName.Substring(0, file.FullName.Length - 4);

                        if (!Directory.Exists(pasta))
                        {
                            Directory.CreateDirectory(pasta);
                        }
                        try
                        {
                            string pastaTemp = $@"{pasta}\tem0001";

                            if (Directory.Exists(pastaTemp))
                            {
                                foreach (FileInfo item in new DirectoryInfo(pastaTemp).GetFiles())
                                {
                                    File.Delete(item.FullName);
                                }
                            }
                            if (!Directory.Exists(pastaTemp))
                            {
                                Directory.CreateDirectory(pastaTemp);
                            }
                            ZipFile.ExtractToDirectory($@"{file.FullName}", pastaTemp);

                            foreach (FileInfo item in new DirectoryInfo(pastaTemp).GetFiles())
                            {
                                string caminhoArquivoDestino = Path.Combine(pasta, item.Name);
                                item.CopyTo(caminhoArquivoDestino, true);

                            }
                            if (Directory.Exists(pastaTemp))
                            {
                                Directory.Delete(pastaTemp, true);
                            }
                        }

                        catch { }
                    }
                }
                if (MessageBox.Show("Arquivos do sistema extraido(s) com sucesso!\nDeseja executar o sistema?", "Atenção!",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (File.Exists($@"{zipPasta}\{ConfigurationManager.AppSettings.Get("nomeExec")}"))
                    {
                        Process.Start($@"{zipPasta}\{ConfigurationManager.AppSettings.Get("nomeExec")}");
                    }
                    else
                    {
                        MessageBox.Show($"Sistema não {ConfigurationManager.AppSettings.Get("nomeExec")} localizado!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }

                /*
                 FileVersionInfo.GetVersionInfo(Path.Combine(@"C:\Spool", "ArquivoZip.exe"));
                 FileVersionInfo myFileVersionInfo = FileVersionInfo.GetVersionInfo(@"C:\Spool" + "\\ArquivoZip.exe");
                 MessageBox.Show("File: " + myFileVersionInfo.FileDescription + '\n' +
                    "Version number: " + myFileVersionInfo.FileVersion);
                */
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {

                MessageBox.Show("Salva com sucesso!", "Configuração!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbBancoDeDados_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbVersaoSistemaAtual.SelectedIndex = cmbVersaoSistemaAtual.Items.IndexOf(txtVersaoSistemaBancoSelecionado.Text.Replace(".", ""));
        }

        private void chkExibirSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkExibirSenha.Checked)
            {
                txtSenha.PasswordChar = default;
            }
            else
            {
                txtSenha.PasswordChar = '*';
            }
        }

        private void chkUsarBancoINI_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkUsarBancoINI.Checked)
            {
                txtServidor.Text = Environment.MachineName;
                this.Enabled = false;
                //grpInfoBancoDeDados.Enabled = false;
                txtBancoDeDados.Clear();
                ExibirInstanciaSQL();
                //grpInfoBancoDeDados.Enabled = true;
                this.Enabled = true;

            }
            else
            {
            }


        }

        private void cmbInstanciaSQL_SelectedIndexChanged(object sender, EventArgs e)
        {
            ExibirInfoSQL();
            ExibirBancoDeDados();
        }

        private void btnTestarConexao_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

                builder.DataSource = $@"{txtServidor.Text.Trim()}\{cmbInstanciaSQL.Text.Trim()}";
                builder.UserID = txtUsuario.Text.Trim();
                builder.Password = txtSenha.Text.Trim();
                builder.InitialCatalog = string.IsNullOrWhiteSpace(cmbBancoDeDados.Text.Trim()) ? cmbBancoDeDados.Text : cmbBancoDeDados.Text.Trim();

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    MessageBox.Show($"Conexão realizada com sucesso!", "Status!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbVersaoSistemaAtual_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDiretorioSistema.Text = $@"{ConfigurationManager.AppSettings.Get("diretorioSistema")}\{txtBancoDeDados.Text.Trim()}{cmbVersaoSistemaAtual.Text.Replace(".", "")}";
        }
    }
}
