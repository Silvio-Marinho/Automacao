﻿namespace AutomacaoBancoSistema
{
    partial class frmConexao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpInfoBancoDeDados = new System.Windows.Forms.GroupBox();
            this.txtVersaoSistemaBancoINI = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSQLInfo = new System.Windows.Forms.TextBox();
            this.btnTestarConexao = new System.Windows.Forms.Button();
            this.cmbInstanciaSQL = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.txtVersaoSistemaBancoSelecionado = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbBancoDeDados = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.chkExibirSenha = new System.Windows.Forms.CheckBox();
            this.chkUsarBancoINI = new System.Windows.Forms.CheckBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBancoDeDados = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpInfoSistema = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtDiretorioSistema = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbVersaoSistemaAtual = new System.Windows.Forms.ComboBox();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRepositorioSistema = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.grpInfoBancoDeDados.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpInfoSistema.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // grpInfoBancoDeDados
            // 
            this.grpInfoBancoDeDados.Controls.Add(this.txtVersaoSistemaBancoINI);
            this.grpInfoBancoDeDados.Controls.Add(this.label12);
            this.grpInfoBancoDeDados.Controls.Add(this.label11);
            this.grpInfoBancoDeDados.Controls.Add(this.label10);
            this.grpInfoBancoDeDados.Controls.Add(this.txtSQLInfo);
            this.grpInfoBancoDeDados.Controls.Add(this.btnTestarConexao);
            this.grpInfoBancoDeDados.Controls.Add(this.cmbInstanciaSQL);
            this.grpInfoBancoDeDados.Controls.Add(this.groupBox2);
            this.grpInfoBancoDeDados.Controls.Add(this.chkExibirSenha);
            this.grpInfoBancoDeDados.Controls.Add(this.chkUsarBancoINI);
            this.grpInfoBancoDeDados.Controls.Add(this.txtSenha);
            this.grpInfoBancoDeDados.Controls.Add(this.label5);
            this.grpInfoBancoDeDados.Controls.Add(this.txtUsuario);
            this.grpInfoBancoDeDados.Controls.Add(this.label4);
            this.grpInfoBancoDeDados.Controls.Add(this.txtBancoDeDados);
            this.grpInfoBancoDeDados.Controls.Add(this.label2);
            this.grpInfoBancoDeDados.Controls.Add(this.txtServidor);
            this.grpInfoBancoDeDados.Controls.Add(this.label1);
            this.grpInfoBancoDeDados.Location = new System.Drawing.Point(12, 12);
            this.grpInfoBancoDeDados.Name = "grpInfoBancoDeDados";
            this.grpInfoBancoDeDados.Size = new System.Drawing.Size(370, 532);
            this.grpInfoBancoDeDados.TabIndex = 0;
            this.grpInfoBancoDeDados.TabStop = false;
            this.grpInfoBancoDeDados.Text = "Informações do banco de dados";
            // 
            // txtVersaoSistemaBancoINI
            // 
            this.txtVersaoSistemaBancoINI.Enabled = false;
            this.txtVersaoSistemaBancoINI.Location = new System.Drawing.Point(263, 256);
            this.txtVersaoSistemaBancoINI.Name = "txtVersaoSistemaBancoINI";
            this.txtVersaoSistemaBancoINI.Size = new System.Drawing.Size(97, 20);
            this.txtVersaoSistemaBancoINI.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(263, 240);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Versão";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 240);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Banco de Dados";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Informações(s) Extra(s) do SQL";
            // 
            // txtSQLInfo
            // 
            this.txtSQLInfo.Location = new System.Drawing.Point(9, 145);
            this.txtSQLInfo.Multiline = true;
            this.txtSQLInfo.Name = "txtSQLInfo";
            this.txtSQLInfo.Size = new System.Drawing.Size(351, 92);
            this.txtSQLInfo.TabIndex = 16;
            // 
            // btnTestarConexao
            // 
            this.btnTestarConexao.Location = new System.Drawing.Point(9, 499);
            this.btnTestarConexao.Name = "btnTestarConexao";
            this.btnTestarConexao.Size = new System.Drawing.Size(112, 23);
            this.btnTestarConexao.TabIndex = 15;
            this.btnTestarConexao.Text = "Testar Conexão";
            this.btnTestarConexao.UseVisualStyleBackColor = true;
            this.btnTestarConexao.Click += new System.EventHandler(this.btnTestarConexao_Click);
            // 
            // cmbInstanciaSQL
            // 
            this.cmbInstanciaSQL.FormattingEnabled = true;
            this.cmbInstanciaSQL.Location = new System.Drawing.Point(9, 105);
            this.cmbInstanciaSQL.Name = "cmbInstanciaSQL";
            this.cmbInstanciaSQL.Size = new System.Drawing.Size(351, 21);
            this.cmbInstanciaSQL.TabIndex = 16;
            this.cmbInstanciaSQL.SelectedIndexChanged += new System.EventHandler(this.cmbInstanciaSQL_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSalvar);
            this.groupBox2.Controls.Add(this.txtVersaoSistemaBancoSelecionado);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cmbBancoDeDados);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(9, 383);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(351, 110);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Selecionar outro Banco de Dados";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(9, 68);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(75, 23);
            this.btnSalvar.TabIndex = 14;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // txtVersaoSistemaBancoSelecionado
            // 
            this.txtVersaoSistemaBancoSelecionado.Enabled = false;
            this.txtVersaoSistemaBancoSelecionado.Location = new System.Drawing.Point(248, 41);
            this.txtVersaoSistemaBancoSelecionado.Name = "txtVersaoSistemaBancoSelecionado";
            this.txtVersaoSistemaBancoSelecionado.Size = new System.Drawing.Size(97, 20);
            this.txtVersaoSistemaBancoSelecionado.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(248, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Versão";
            // 
            // cmbBancoDeDados
            // 
            this.cmbBancoDeDados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBancoDeDados.FormattingEnabled = true;
            this.cmbBancoDeDados.Location = new System.Drawing.Point(9, 41);
            this.cmbBancoDeDados.Name = "cmbBancoDeDados";
            this.cmbBancoDeDados.Size = new System.Drawing.Size(233, 21);
            this.cmbBancoDeDados.TabIndex = 10;
            this.cmbBancoDeDados.SelectedIndexChanged += new System.EventHandler(this.cmbBancoDeDados_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Banco de dados";
            // 
            // chkExibirSenha
            // 
            this.chkExibirSenha.AutoSize = true;
            this.chkExibirSenha.Location = new System.Drawing.Point(9, 360);
            this.chkExibirSenha.Name = "chkExibirSenha";
            this.chkExibirSenha.Size = new System.Drawing.Size(85, 17);
            this.chkExibirSenha.TabIndex = 11;
            this.chkExibirSenha.Text = "Exibir Senha";
            this.chkExibirSenha.UseVisualStyleBackColor = true;
            this.chkExibirSenha.CheckedChanged += new System.EventHandler(this.chkExibirSenha_CheckedChanged);
            // 
            // chkUsarBancoINI
            // 
            this.chkUsarBancoINI.AutoSize = true;
            this.chkUsarBancoINI.Checked = true;
            this.chkUsarBancoINI.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUsarBancoINI.Location = new System.Drawing.Point(9, 23);
            this.chkUsarBancoINI.Name = "chkUsarBancoINI";
            this.chkUsarBancoINI.Size = new System.Drawing.Size(166, 17);
            this.chkUsarBancoINI.TabIndex = 10;
            this.chkUsarBancoINI.Text = "Usar Banco de Dados do .INI";
            this.chkUsarBancoINI.UseVisualStyleBackColor = true;
            this.chkUsarBancoINI.CheckedChanged += new System.EventHandler(this.chkUsarBancoINI_CheckedChanged);
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(9, 334);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(351, 20);
            this.txtSenha.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 318);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Senha";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(9, 295);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(351, 20);
            this.txtUsuario.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 279);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Usuário";
            // 
            // txtBancoDeDados
            // 
            this.txtBancoDeDados.Location = new System.Drawing.Point(9, 256);
            this.txtBancoDeDados.Name = "txtBancoDeDados";
            this.txtBancoDeDados.Size = new System.Drawing.Size(248, 20);
            this.txtBancoDeDados.TabIndex = 5;
            this.txtBancoDeDados.Text = "TESTE_DB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Instância SQL";
            // 
            // txtServidor
            // 
            this.txtServidor.Location = new System.Drawing.Point(9, 66);
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(351, 20);
            this.txtServidor.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Servidor";
            // 
            // grpInfoSistema
            // 
            this.grpInfoSistema.Controls.Add(this.pictureBox1);
            this.grpInfoSistema.Controls.Add(this.txtDiretorioSistema);
            this.grpInfoSistema.Controls.Add(this.label8);
            this.grpInfoSistema.Controls.Add(this.cmbVersaoSistemaAtual);
            this.grpInfoSistema.Controls.Add(this.btnExecutar);
            this.grpInfoSistema.Controls.Add(this.label9);
            this.grpInfoSistema.Controls.Add(this.txtRepositorioSistema);
            this.grpInfoSistema.Controls.Add(this.label3);
            this.grpInfoSistema.Location = new System.Drawing.Point(388, 12);
            this.grpInfoSistema.Name = "grpInfoSistema";
            this.grpInfoSistema.Size = new System.Drawing.Size(379, 530);
            this.grpInfoSistema.TabIndex = 13;
            this.grpInfoSistema.TabStop = false;
            this.grpInfoSistema.Text = "Informações  do Sistema";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(42, 193);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(297, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // txtDiretorioSistema
            // 
            this.txtDiretorioSistema.Enabled = false;
            this.txtDiretorioSistema.Location = new System.Drawing.Point(9, 82);
            this.txtDiretorioSistema.Name = "txtDiretorioSistema";
            this.txtDiretorioSistema.Size = new System.Drawing.Size(364, 20);
            this.txtDiretorioSistema.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Diretório do Sistema";
            // 
            // cmbVersaoSistemaAtual
            // 
            this.cmbVersaoSistemaAtual.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersaoSistemaAtual.FormattingEnabled = true;
            this.cmbVersaoSistemaAtual.Items.AddRange(new object[] {
            "632001",
            "632000"});
            this.cmbVersaoSistemaAtual.Location = new System.Drawing.Point(272, 43);
            this.cmbVersaoSistemaAtual.Name = "cmbVersaoSistemaAtual";
            this.cmbVersaoSistemaAtual.Size = new System.Drawing.Size(101, 21);
            this.cmbVersaoSistemaAtual.TabIndex = 16;
            this.cmbVersaoSistemaAtual.SelectedIndexChanged += new System.EventHandler(this.cmbVersaoSistemaAtual_SelectedIndexChanged);
            // 
            // btnExecutar
            // 
            this.btnExecutar.Location = new System.Drawing.Point(9, 106);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(112, 23);
            this.btnExecutar.TabIndex = 16;
            this.btnExecutar.Text = "Executar Sistema";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(272, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Versão Atual";
            // 
            // txtRepositorioSistema
            // 
            this.txtRepositorioSistema.Enabled = false;
            this.txtRepositorioSistema.Location = new System.Drawing.Point(9, 43);
            this.txtRepositorioSistema.Name = "txtRepositorioSistema";
            this.txtRepositorioSistema.Size = new System.Drawing.Size(257, 20);
            this.txtRepositorioSistema.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Repositório do Sistema";
            // 
            // frmConexao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 554);
            this.Controls.Add(this.grpInfoSistema);
            this.Controls.Add(this.grpInfoBancoDeDados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmConexao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conexão com Banco";
            this.grpInfoBancoDeDados.ResumeLayout(false);
            this.grpInfoBancoDeDados.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpInfoSistema.ResumeLayout(false);
            this.grpInfoSistema.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpInfoBancoDeDados;
        private System.Windows.Forms.CheckBox chkUsarBancoINI;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBancoDeDados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtServidor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtVersaoSistemaBancoSelecionado;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbBancoDeDados;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkExibirSenha;
        private System.Windows.Forms.GroupBox grpInfoSistema;
        private System.Windows.Forms.Button btnTestarConexao;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRepositorioSistema;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbVersaoSistemaAtual;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.TextBox txtDiretorioSistema;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbInstanciaSQL;
        private System.Windows.Forms.TextBox txtSQLInfo;
        private System.Windows.Forms.TextBox txtVersaoSistemaBancoINI;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

